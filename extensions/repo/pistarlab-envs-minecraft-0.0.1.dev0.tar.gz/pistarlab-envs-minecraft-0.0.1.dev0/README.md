https://minerl.io/docs/tutorials/index.html
https://github.com/juliusfrost/minerl-rllib

```bash
sudo add-apt-repository ppa:openjdk-r/ppa
sudo apt-get update
sudo apt-get install openjdk-8-jdk
```


sudo update-alternatives --config java